import React, {useState} from 'react';
import { PhotoProvider, PhotoView } from 'react-photo-view';
import 'react-photo-view/dist/react-photo-view.css';
import PureModal from 'react-pure-modal';
import './react-modal-styles.css';
import { DocumentViewer } from 'react-documents';
import DocViewer, { DocViewerRenderers } from "react-doc-viewer-updated";

class HometaskFiles extends React.Component {
    constructor(props) {
        super(props); // files
        this.state = { ready: false, isModalOpen: false, currentFileIndex: 0 };
        console.log(this.props);
    }

    componentDidMount() {
    }

    onOpenModal = () => {
        this.setState({ isModalOpen: true });
    };

    onCloseModal = () => {
        this.setState({ isModalOpen: false });
    };

    render() {
        if (this.props.files != undefined) {
            return (
                <div style={{width: '5%'}}>
                    <div style={{display: 'flex', cursor: 'default'}} onClick={this.onOpenModal}>
                        <span style={{width: '30%', marginLeft: 0, marginTop: 0, height: '10px', fontSize: '1.5em', position: 'relative'}} class="material-symbols-rounded">expand_more</span>
                        <span style={{width: '70%'}}>Файлы</span>
                    </div>

                    <PureModal width="90%" isOpen={this.state.isModalOpen} onClose={this.onCloseModal}>
                        <br />
                        {this.mapFiles()}
                    </PureModal>
                </div>);
        } else return (<div style={{display: 'flex', width: '5%'}}>  </div>);
    }

    mapFiles() {
        if (this.props.files != undefined) {

            // state: currentFileIndex
            let docs = [];

            this.props.files.name.map((name) => {
                let fileURI = "http://45.130.146.121:8090/api/files/hometasks/" + this.props.files.hometaskID + "/" + name;
                docs.push(fileURI);
            });

            console.log('docs ');
            console.log(docs/*.at(-1)*/);
            console.log(docs[this.state.currentFileIndex]);

            //<DocumentViewer
                //queryParams="ru=Ru"
                //url={'http://45.130.146.121/api/files/hometasks/4z03ki3knoqdk6d/Uak8AHNkJ3_Vzv6RvTXpI.docx'}
                //viewer="google"
                //style={{height: '80vh', width: '100%'}}>
            //</DocumentViewer>
                    //<img style={{display: 'grid', justifySelf: 'center'}} src="http://45.130.146.121/api/files/hometasks/gxhfe86ief5siwn/kg0RzPCAqT_u2aLXU28bK.jpg" />
            let ext = docs[this.state.currentFileIndex].split('.').at(-1);
            console.log(ext);

            return (
                <div style={{width: '100%', display: 'grid'}}>
                    <div style={{width: '18em',  marginBottom: '1em', marginTop: '1em', background: '#161616', height: '3em', display: 'grid', borderRadius: '15px', marginRight: '1em', gridAutoFlow: 'column', justifySelf: 'end'}}>
                        <span
                            onClick={ () => { if (this.state.currentFileIndex > 0) this.setState({currentFileIndex: this.state.currentFileIndex - 1}); } }
                            style={{cursor: 'default', userSelect: 'none', width: '1em', marginLeft: '0.5em', marginTop: '0', height: '1em', fontSize: '1.5em', position: 'relative', marginTop: '0.5em', display: 'grid', justifySelf: 'start'}}
                            className="material-symbols-rounded">
                        arrow_back_ios</span>


                        <span style={{marginTop: 0, display: 'grid', justifySelf: 'center', alignSelf: 'center', textAlign: 'center'}}>Документ {this.state.currentFileIndex + 1} из {docs.length}</span>


                        <a
                            href={docs[this.state.currentFileIndex]} download={true}
                            style={{cursor: 'default', color: 'white', textDecoration: 'none', userSelect: 'none', width: '1em', marginRight: '0.25em', height: '1em', fontSize: '1.5em', position: 'relative', marginTop: '0.5em', justifySelf: 'end', display: 'grid'}}
                            className="material-symbols-rounded">
                        download</a>
                        <span
                            onClick={ () => { if (this.state.currentFileIndex < docs.length) this.setState({currentFileIndex: this.state.currentFileIndex + 1}); } }
                            style={{cursor: 'default', userSelect: 'none', width: '1em', marginRight: '0.25em', height: '1em', fontSize: '1.5em', position: 'relative', marginTop: '0.5em', justifySelf: 'end', display: 'grid'}}
                            className="material-symbols-rounded">
                        arrow_forward_ios</span>
                    </div>

                    {this.renderDoc(docs)}
                </div>
            );
        }
    }

    renderDoc(docs) {
        let ext = docs[this.state.currentFileIndex].split('.').at(-1);
        console.log(ext);
        if (ext == 'jpg' || ext == 'png' || ext == 'jpeg') {
            return (<img style={{display: 'grid', justifySelf: 'center'}} src={docs[this.state.currentFileIndex]} />);
        }
        else {
            return (
                <DocumentViewer
                    queryParams="ru=Ru"
                    url={docs[this.state.currentFileIndex]}
                    viewer="google"
                    style={{height: '80vh', width: '100%'}}>
                </DocumentViewer>
            );
        }
    }
}

export default HometaskFiles
