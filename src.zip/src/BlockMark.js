import React from 'react';
import Popover from 'react-awesome-popover';
import './MarkBlock.css';

class BlockMark extends React.Component {

    constructor(props) {
        super(props); //marks
        this.state = {markJsx: undefined, isPopoverOpen: false, ready: false};
    }

    async componentDidMount() {
        const popoverDivStyle = {
            background: '#151515',
            width: '200%',
            height: '200%',
            textAlign: 'center',
            fontSize: '1.5em',
            position: 'relative',
            right: '10%',
            borderRadius: '10px',
            marginBottom: '20%'
        };

        console.log(this.props.marks);
        let dateText = this.props.marks.date.split('-')[2] + '.' + this.props.marks.date.split('-')[1];
        let marks = Array.from(this.props.marks.mark);
        let jsx;
        if (this.props.marks.reason != "") {
            jsx = marks.map((mark) =>
            <div>
                <Popover placement="top-start" arrow={false} stopPropagation={true}>
                    <div className="blockMark" onClick={() => this.setState({isPopoverOpen: !this.state.isPopoverOpen})}>
                        <p className="markDate">{dateText}</p>
                        <div className="blockMarksAndIcon">
                            <span className="blockMarkText">{mark}</span>
                            <span className="material-symbols-rounded">mode_comment</span>
                        </div>
                    </div>
                    <div style={popoverDivStyle}>{this.props.marks.reason}</div>
                </Popover>
            </div>
        );
        } else {
            jsx = marks.map((mark) =>
            <div className="blockMark">
                <p className="markDate">{dateText}</p>
                <div className="blockMarksAndIcon">
                    <span className="blockMarkText">{mark}</span>
                </div>
            </div>);
        }

        this.setState({markJsx: jsx, ready: true});

        this.forceUpdate();
    }

    render() {
        if (this.state.ready == true) {
            if (this.state.markJsx !== undefined) { return (this.state.markJsx); }
            else { return (<div className="blockMark">⠀</div>); }
        }
    }
}

export default BlockMark
