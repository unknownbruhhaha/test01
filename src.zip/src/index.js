import React, { useState, useRef } from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import shortid from 'shortid';
import Day from './Day.js';
import WeekSelector from './WeekSelector.js';
import StudentMarks from './StudentMarks.js';
import reportWebVitals from './reportWebVitals';
import PocketBase from 'pocketbase';
import { PhotoProvider, PhotoView } from 'react-photo-view';
import 'react-photo-view/dist/react-photo-view.css';

const pb = new PocketBase('http://45.130.146.121:8090');
let authData;
let isTeacher;
let loginErr;
let currentWeekMonday;

const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(<div><Login /></div>);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
//reportWebVitals();

function Login() {
  const [wrongPass, setWrongPass] = useState("  ");
  const loginRef = useRef(null);
  const passRef = useRef(null);

  async function formSubmitted(e) {
    e.preventDefault();

    pb.autoCancellation(false);

    var div = document.getElementById('Login');

    try {
      authData = await pb.collection('users').authWithPassword(loginRef.current.value, passRef.current.value);
    } catch (err) {
      setWrongPass("\n\nНеправльный логин или пароль");
      return;
    }

    isTeacher = authData.record.isTeacher;

    root.render(<div><Navbar /> <StudentScheulde /></div>);
    return;
  }

  return (
    <div id="Login" className='login'>

    <div className="loginInner">
        <form onSubmit={formSubmitted}>
          <b>Авторизация</b>
          <input type="text" placeholder="Введите логин" name="login" ref={loginRef} /><br/>
          <input type="password" placeholder="Введите пароль" name="pass" ref={passRef} /><br/>
          <button type="submit" id="loginBtn">Войти</button>
          <p>{wrongPass}</p>
        </form>
    </div>
  </div>
  );
}

function StudentScheulde() {
  const [week, setWeek] = useState(0);
  const [jsx, setJsx] = useState(
    <>
        <WeekSelector weekChangerHandler={weekChangerHandler} />
        <Day key={0} dayOfWeek={0} mondayDate={addWeeks(getMonday(new Date()), week).toISOString().slice(0,10)} pb={pb} authData={authData} />
        <Day key={1} dayOfWeek={1} mondayDate={addWeeks(getMonday(new Date()), week).toISOString().slice(0,10)} pb={pb} authData={authData} />
      </>
  );
  console.log(week);

  function weekChangerHandler (weekNum) {
    setWeek(weekNum);
  }

  return (
    <>
      <WeekSelector weekChangerHandler={weekChangerHandler} />
      <Day key={week + '0'} dayOfWeek={0} mondayDate={addWeeks(getMonday(new Date()), week).toISOString().slice(0,10)} pb={pb} authData={authData} />
      <Day key={week + '1'} dayOfWeek={1} mondayDate={addWeeks(getMonday(new Date()), week).toISOString().slice(0,10)} pb={pb} authData={authData} />
    </>
  );
}

function toStudentScheulde() { root.render(<div><Navbar /> <StudentScheulde /></div>); }

function toStudentMarks() { root.render(<div><Navbar /> <StudentMarks pb={pb} authData={authData} /></div>); }

function logout() { pb.authStore.clear(); root.render(<div><Login /></div>); }

function Navbar() {
  return (
     <div class="topnav" style={{backgroundColor: '#080808'}}>
      <button style={{color:'white'}} onClick={toStudentScheulde}>Расписание</button>
      <button style={{color:'white'}} onClick={toStudentMarks}>Оценки</button>
      <button style={{color:'white'}}>Сообщения</button>
      <button style={{color:'white'}} onClick={logout}>Выйти</button>
    </div>
  );
}

function getMonday(d) {
  d = new Date(d);
  var day = d.getDay(),
      diff = d.getDate() - day + (day == 0 ? -6:1); // adjust when day is sunday
  return new Date(d.setDate(diff));
}

function addWeeks(date, weeks) {
  date.setDate(date.getDate() + 7 * weeks);
  console.log('date : ' + date.toLocaleString());
  return date;
}
