import React, {useState} from 'react';
import './MarkBlock.css';
import BlockMark from './BlockMark.js';

class MarkBlock extends React.Component {

    constructor(props) {
        super(props); //lessonID, lessonName, pb, authData
        this.state = { ready: false };

    }

    async componentDidMount() {
        const marks = await this.props.pb.collection('marks').getList(1, 50, {filter: `lesson.id = "${this.props.lessonID}" && student.id = "${this.props.authData.record.id}"`, sort: '+date'});
        this.setState({marks: marks, ready: true});
    }

    render() {
        if (this.state.ready == true)
        {
            return (
                <div className="blockParent">
                    <div className="block">
                        <p className="blockName">{this.props.lessonName}</p>
                        <div className="blockMarks">
                            {this.state.marks.items.map(mark => (<BlockMark marks={mark}></BlockMark>))}
                        </div>
                    </div>
                </div>
            );
        }
    }
}

export default MarkBlock
