import React, {useState} from 'react';
import './index.css';
import Mark from './Mark.js'
import HometaskFiles from './HometaskFiles';
import { PhotoProvider, PhotoView } from 'react-photo-view';
import 'react-photo-view/dist/react-photo-view.css';

class Day extends React.Component {
    constructor(props) {
        super(props);
        console.log(props);
        this.state = {
            ready: false
        };
    }

    async fetchData() {
        if (!this.state.ready) {
            console.log(this.state);
            let classInDB = await this.props.pb.collection('classes').getFirstListItem(`id = "${this.props.authData.record.class}"`, {});
            let scheuldeData = await this.props.pb.collection('scheulde').getFirstListItem(`class.name = "${classInDB.name}" && group = ${this.props.authData.record.group} && weekDayNumber = ${this.props.dayOfWeek}`, {});
            let lessonsArr = new Array(scheuldeData['lesson1'], scheuldeData['lesson2'], scheuldeData['lesson3'], scheuldeData['lesson4'], scheuldeData['lesson5'], scheuldeData['lesson6'], scheuldeData['lesson7'], scheuldeData['lesson8']);

            let tempLessonsNames = new Array();
            for (let i = 0; i < 8; i++)
            {
                if (lessonsArr[i] != "") {
                    let lessonInDB = await this.props.pb.collection('lessons').getOne(lessonsArr[i], {});
                    tempLessonsNames.push(lessonInDB.name);
                }
                else { tempLessonsNames.push("***"); }
            }

            const resultList = await this.props.pb.collection('hometasks').getFullList(200, {filter: `date = "${this.state.currentDayDate}" && class.id = "${this.props.authData.record.class}"`});
            let currentHometaskText;
            let tempHometaskTexts = new Array();
            let files = new Array();
            let filesURLs = new Array();
            for (var i = 0; i < resultList.length; i++) {
                if (resultList[i] !== undefined) currentHometaskText = resultList[i].hometaskText;
                else currentHometaskText = "⠀";
                let currentHometaskLessonID = resultList[i].lesson;
                for (var j = 0; j < lessonsArr.length; j++) {
                    if (lessonsArr[j] == currentHometaskLessonID) {
                        tempHometaskTexts[j] = currentHometaskText;
                        files[j] = {name: resultList[i].files, hometaskID: resultList[i].id};
                        //filesURLs[j] = "localhost:8090/api/files/hometasks/" + resultList[i].id + "/" + files[j][k];
                    }
                }
            }

            console.log(filesURLs);

            let marksArray = new Array();
            for (let i = 0; i < 8; i++)
            {
                marksArray.push((<Mark key={i} lesson={tempLessonsNames[i]} date={this.state.currentDayDate} authData={this.props.authData} pb={this.props.pb}/>));
            }

            this.setState({lessonsNames: tempLessonsNames, hometaskTexts: tempHometaskTexts, marks: marksArray, ready: true, files: files}, () => { console.log(this.state.hometaskTexts); this.forceUpdate() });
        }
    }

    getDayName(date) {
        return date.toLocaleString('ru-ru', {weekday:'long'}).split(' ')[0];
    }

    componentDidMount() {
        var currentDayDate = new Date();
        currentDayDate.setFullYear(this.props.mondayDate.split('-')[0]);
        currentDayDate.setMonth(this.props.mondayDate.split('-')[1]);
        currentDayDate.setDate(Number(this.props.mondayDate.split('-')[2]) + this.props.dayOfWeek);
        console.log(currentDayDate);
        var dayName = currentDayDate.toLocaleDateString('ru-ru', {weekday:'long'});

        var currentDayDateStr = ('0' + currentDayDate.getDate()).slice(-2) + '.'
                    + ('0' + (currentDayDate.getMonth())).slice(-2) + '.'
                    + currentDayDate.getFullYear();

        var currentDayDate1 = (currentDayDate.getFullYear() + '-' + ('0' + (currentDayDate.getMonth())).slice(-2) + '-' + ('0' + currentDayDate.getDate()).slice(-2));
        console.log(currentDayDate1);
        this.setState({currentDayDateString: currentDayDateStr, currentDayDate: currentDayDate1, dayName: dayName[0].toUpperCase() + dayName.slice(1), ready: false}, () => this.fetchData());
    }

    render() {
        if (this.state.ready) {
            //console.log({currentDayDateString});
            return(
            <div>
                <br /><br />

                <div className="scheuldeDay">
                    <div className="scheuldeDayInner">
                        <div className="scheuldeDayBr" />
                        <h2>{this.state.dayName} ({this.state.currentDayDateString})</h2>
                        <div className="lesson"><span className="lessonName">1. {this.state.lessonsNames[0]}</span><span className="hometask">{this.state.hometaskTexts[0]}</span><HometaskFiles files={this.state.files[0]} />{this.state.marks[0]}</div><hr />
                        <div className="lesson"><span className="lessonName">2. {this.state.lessonsNames[1]}</span><span className="hometask">{this.state.hometaskTexts[1]}</span><HometaskFiles files={this.state.files[1]} />{this.state.marks[1]}</div><hr />
                        <div className="lesson"><span className="lessonName">3. {this.state.lessonsNames[2]}</span><span className="hometask">{this.state.hometaskTexts[2]}</span><HometaskFiles files={this.state.files[2]} />{this.state.marks[2]}</div><hr />
                        <div className="lesson"><span className="lessonName">4. {this.state.lessonsNames[3]}</span><span className="hometask">{this.state.hometaskTexts[3]}</span><HometaskFiles files={this.state.files[3]} />{this.state.marks[3]}</div><hr />
                        <div className="lesson"><span className="lessonName">5. {this.state.lessonsNames[4]}</span><span className="hometask">{this.state.hometaskTexts[4]}</span><HometaskFiles files={this.state.files[4]} />{this.state.marks[4]}</div><hr />
                        <div className="lesson"><span className="lessonName">6. {this.state.lessonsNames[5]}</span><span className="hometask">{this.state.hometaskTexts[5]}</span><HometaskFiles files={this.state.files[5]} />{this.state.marks[5]}</div><hr />
                        <div className="lesson"><span className="lessonName">7. {this.state.lessonsNames[6]}</span><span className="hometask">{this.state.hometaskTexts[6]}</span><HometaskFiles files={this.state.files[6]} />{this.state.marks[6]}</div><hr />
                        <div className="lesson"><span className="lessonName">8. {this.state.lessonsNames[7]}</span><span className="hometask">{this.state.hometaskTexts[7]}</span><HometaskFiles files={this.state.files[7]} />{this.state.marks[7]}</div>
                        <br/><div className="scheuldeDayBr" />
                    </div>
                </div>
            </div>);
        }
    }
}

export default Day;
