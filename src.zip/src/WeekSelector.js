import React, {useState} from 'react';
import './index.css';

class WeekSelector extends React.Component {
    constructor(props) {
        super(props); // weekChangerHandler
        this.state = { week: 0 }
    }

    render() {
        let weekName;
        if (this.state.week == undefined || this.state.week == 0) weekName = "Текущая неделя";
        else if (this.state.week == -1) weekName = "Предыдущая неделя";
        else if (this.state.week == 1) weekName = "Следующая неделя";
        else {
            let monday = getMonday(addDays(new Date(), 7 * this.state.week));
            let sunday = addDays(getMonday(addDays(new Date(), 7 * this.state.week)), 6);
            let mondayString = monday.toLocaleString();
            let sundayString = sunday.toLocaleString();
            weekName = mondayString.split('/')[1] + '.' + mondayString.split('/')[0]
                + ' - ' + sundayString.split('/')[1] + '.' + sundayString.split('/')[0];

        }

        return (
            <div style={{display: 'grid'}}>
                <div style={{width: '18em', marginTop: '1em', background: '#161616', height: '3em', display: 'grid', borderRadius: '15px', marginRight: '1em', gridAutoFlow: 'column', justifySelf: 'end'}}>
                    <span
                        onClick={ () => { this.setState({week: this.state.week - 1}); this.props.weekChangerHandler(this.state.week - 1); } }
                        style={{cursor: 'default', userSelect: 'none', width: '1em', marginLeft: '0.5em', marginTop: '0', height: '1em', fontSize: '1.5em', position: 'relative', marginTop: '0.5em', display: 'grid', justifySelf: 'start'}}
                        className="material-symbols-rounded">
                    arrow_back_ios</span>


                    <span style={{marginTop: 0, display: 'grid', justifySelf: 'center', alignSelf: 'center', textAlign: 'center'}}>{weekName}</span>


                    <span
                        onClick={ () => { this.setState({week: this.state.week + 1}); this.props.weekChangerHandler(this.state.week + 1); } }
                        style={{cursor: 'default', userSelect: 'none', width: '1em', marginRight: '0.25em', height: '1em', fontSize: '1.5em', position: 'relative', marginTop: '0.5em', justifySelf: 'end', display: 'grid'}}
                        className="material-symbols-rounded">
                    arrow_forward_ios</span>
                </div>
            </div>
        );
    }
}

function getMonday(d) {
  d = new Date(d);
  var day = d.getDay(),
      diff = d.getDate() - day + (day == 0 ? -6:1); // adjust when day is sunday
  return new Date(d.setDate(diff));
}

function addDays(date, days) {
  date.setDate(date.getDate() + days);
  return date;
}


export default WeekSelector
