import React from 'react';
import './index.css';

class Mark extends React.Component {

    constructor(props) {
        super(props);
        this.state = {markJsx: undefined, ready: false};
    }

    async componentDidMount() {
        if (this.props.lesson != "***") {
            const record = await this.props.pb.collection('marks').getFirstListItem(`lesson.name = "${this.props.lesson}" && date = "${this.props.date}" && student.id = "${this.props.authData.record.id}"`, {});
            if (record.message === undefined) {
                const marks = Array.from(record.mark);
                const JSX = marks.map((mark) => <div className="mark">{mark}</div>);
                var markJsx = (<div className="dayMarks">{JSX}</div>);
                this.setState({markJsx: markJsx, ready: true});
            }

            this.forceUpdate();
        }
    }

    render() {
        if (this.state.ready == true) {
            if (this.state.markJsx !== undefined) { return (this.state.markJsx); }
            else { return (<div className="dayMarks">⠀</div>); }
        }
    }
}

export default Mark
