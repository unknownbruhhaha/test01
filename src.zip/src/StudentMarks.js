import React, {useState} from 'react';
import './index.css';
import Mark from './Mark.js'
import MarkBlock from './MarkBlock.js'

class StudentMarks extends React.Component {
    constructor(props) {
        super(props); // pb authData

        this.state = { lessons: undefined, ready: false }
    }

    async componentDidMount() {
        let classInDB = await this.props.pb.collection('classes').getOne(this.props.authData.record.class, {});
        let classLessons = classInDB.lessons;
        let lessons = new Array();
        for (var i = 0; i < classLessons.length; i++) {
            let id = classLessons[i];
            let lesson = await this.props.pb.collection('lessons').getOne(id, {});
            lessons.push(lesson);
        };

        this.setState({lessons: lessons, ready: true});
    }

    render() {
        if (this.state.ready) {
            return (
                <div>
                    {this.state.lessons.map(lesson => { return (<MarkBlock lessonName={lesson.name} lessonID={lesson.id} pb={this.props.pb} authData={this.props.authData} />) })}
                </div>
            );
        }
    }
}

export default StudentMarks
